import time

from pip._vendor.distlib.compat import raw_input

UserName = raw_input("What is your name? ")

print("Hello " + UserName + " . Ready to play Hangman ! ")
print("")

time.sleep(1)
print()
"Start Guessing..."
time.sleep(0.5)

word = "secret"

guesses = ''

turns = 10

while turns > 0:

    failed = 0

    for char in word:
        if char in guesses:
            print(char)

        else:
            print("_")

            failed += 1

    if failed == 0:
        print("YOU WON !!!")

    break

    print("")

    guess = raw_input("Guess a Character: ")

    guesses += guess

    if guess not in word:

        turns -= 1

        print("Wrong Guess !")

    print("You have " + turns + " guesses left")

    if turns == 0:

        print("YOU LOOSE !!!")







